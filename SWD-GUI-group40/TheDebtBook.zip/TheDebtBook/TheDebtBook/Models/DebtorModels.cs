﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheDebtBook.Models
{
    public class DebtorModels
    {
        public string Name { get; set; }

        public int Amount { get; set; }

    }
}
